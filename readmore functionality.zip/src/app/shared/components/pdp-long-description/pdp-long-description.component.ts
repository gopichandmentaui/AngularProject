import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdp-long-description',
  templateUrl: './pdp-long-description.component.html',
  styleUrls: ['./pdp-long-description.component.scss']
})
export class PdpLongDescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
