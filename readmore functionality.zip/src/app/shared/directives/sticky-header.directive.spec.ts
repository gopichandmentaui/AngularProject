import { StickyHeaderDirective } from './sticky-header.directive';

describe('StickyHeaderDirective', () => {
  it('should create an instance', () => {
    const directive = new StickyHeaderDirective();
    expect(directive).toBeTruthy();
  });
});
