export const OVERVIEW_DATA_URL = "/assets/json/overview.json";

export const SPECIFICATIONS_URL = "/assets/json/specifications.json"